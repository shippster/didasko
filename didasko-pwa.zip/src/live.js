/* ================= Live sessions (presenter side) =================
   sessions/{CODE}: host, active, title, captions/{id}, interim, participants/{uid}, quiz, reveal/{i}, responses/{i}/{uid}, scores/{uid} */
const LIVE = { code: null, ref: null, people: {}, langs: new Set(), offs: [], showQR: false, interimAt: 0, interimTimer: null, q: null };
const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const MAX_LIVE_LANGS = 10;
const genCode = () => Array.from(crypto.getRandomValues(new Uint8Array(6)), b => CODE_CHARS[b % CODE_CHARS.length]).join('');
function joinUrl(code, quiz) {
  const base = (CFG.appUrl || (location.origin + location.pathname)).replace(/index\.html?$/, '');
  return `${base}?join=${code}${quiz ? '&quiz=1' : ''}`;
}
const shortUrl = u => u.replace(/^https?:\/\//, '').replace(/\/?\?join=/, '/?join=');
async function qrSvg(text) {
  try {
    const qr = (await lib('qr'))(0, 'M'); qr.addData(text); qr.make();
    const n = qr.getModuleCount(), m = 2; let d = '';
    for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (qr.isDark(r, c)) d += `M${c + m} ${r + m}h1v1h-1z`;
    return `<svg role="img" aria-label="QR code to join" class="qr-svg" viewBox="0 0 ${n + 2 * m} ${n + 2 * m}" shape-rendering="crispEdges"><rect width="100%" height="100%" fill="#fff"/><path d="${d}" fill="#000"/></svg>`;
  } catch { return ''; }
}
const segPayload = s => { const p = { t: s.t, kind: s.kind, text: s.text }; if (s.key) p.key = true; if (s.tr && Object.keys(s.tr).length) p.tr = s.tr; return p; };
function liveSeg(seg) { if (LIVE.ref && seg) LIVE.ref.child('captions/' + seg.id).set(segPayload(seg)).catch(() => {}); }
function liveDelSeg(id) { if (LIVE.ref) LIVE.ref.child('captions/' + id).remove().catch(() => {}); }
function liveTr(seg, lang, text) { if (LIVE.ref) LIVE.ref.child(`captions/${seg.id}/tr/${lang}`).set(text).catch(() => {}); }
function liveMeta() { if (LIVE.ref) LIVE.ref.update({ title: S.lecture.title, course: S.lecture.course || '', srcLang: S.settings.srcLang }).catch(() => {}); }
function liveInterim(text) {
  if (!LIVE.ref) return;
  clearTimeout(LIVE.interimTimer);
  const send = () => { LIVE.interimAt = Date.now(); LIVE.ref.child('interim').set(text ? { text } : null).catch(() => {}); };
  if (!text || Date.now() - LIVE.interimAt > 600) send(); else LIVE.interimTimer = setTimeout(send, 600);
}
function liveTargets() { const t = new Set(LIVE.langs); if (target()) t.add(target()); return [...t]; }
async function startSharing() {
  try { await ensureAuth(); } catch (e) { toast(e.message, 5000); return false; }
  const uid = CLOUD.user.uid, L = S.lecture, db = CLOUD.db;
  let code = L.liveCode || null;
  try {
    if (code && (await db.ref(`sessions/${code}/host`).once('value')).val() !== uid) code = null;
    for (let i = 0; !code && i < 6; i++) { const c = genCode(); if (!(await db.ref(`sessions/${c}/host`).once('value')).exists()) code = c; }
    if (!code) throw new Error('no code');
    LIVE.code = code; LIVE.ref = db.ref('sessions/' + code);
    await LIVE.ref.update({ host: uid, active: true, startedAt: TS(), title: L.title, course: L.course || '', srcLang: S.settings.srcLang, lecturer: lecturerOf(L) });
  } catch (e) { LIVE.code = null; LIVE.ref = null; toast('Couldn’t start sharing. Check your connection and the Firebase setup.', 5000); return false; }
  L.liveCode = code; saveSoon();
  const upd = {}; L.segments.slice(-40).forEach(s => { upd['captions/' + s.id] = segPayload(s); });
  if (Object.keys(upd).length) LIVE.ref.update(upd).catch(() => {});
  const pref = LIVE.ref.child('participants');
  const cb = pref.on('value', snap => { LIVE.people = snap.val() || {}; onPeople(); });
  LIVE.offs.push(() => pref.off('value', cb));
  renderShare();
  return true;
}
function stopSharing(silent) {
  if (!LIVE.ref) return;
  LIVE.ref.update({ active: false, interim: null, quiz: null }).catch(() => {});
  LIVE.offs.forEach(f => f()); LIVE.offs = [];
  if (LIVE.q) closeLiveQuiz(true);
  Object.assign(LIVE, { code: null, ref: null, people: {}, langs: new Set(), showQR: false, q: null });
  renderShare(); renderStageQR();
  if (!silent) toast('Sharing stopped. Students see that the session has ended.');
}
function onPeople() {
  const online = Object.values(LIVE.people).filter(p => p.online !== false);
  const before = new Set(LIVE.langs);
  LIVE.langs = new Set(online.map(p => p.lang).filter(l => l && l !== 'off' && l !== srcBase(S.settings.srcLang)).slice(0, MAX_LIVE_LANGS));
  for (const lang of LIVE.langs) if (!before.has(lang)) speechSegs(S.lecture).slice(-6).forEach(s => queueTranslate(s, lang));
  renderShare();
  if (LIVE.q) renderLiveQuiz();
}
function peopleSummary() {
  const online = Object.values(LIVE.people).filter(p => p.online !== false);
  const by = {}; online.forEach(p => { const l = p.lang && p.lang !== 'off' ? p.lang : 'orig'; by[l] = (by[l] || 0) + 1; });
  return { n: online.length, by };
}
function renderShare() {
  const chip = $('#share-chip'), txt = $('#share-text'), btn = $('#btn-share'), qb = $('#btn-qr-stage');
  if (!chip) return;
  if (!LIVE.code) {
    chip.textContent = 'Off'; chip.className = 'chip';
    txt.textContent = 'Let students follow the captions on their own phone or laptop and choose their own translation. They don’t need an account.';
    btn.innerHTML = `${icon('qr')}Share captions`; qb.hidden = true; return;
  }
  const { n, by } = peopleSummary();
  chip.textContent = `${n} connected`; chip.className = 'chip ok';
  const langs = Object.entries(by).map(([l, c]) => `${l === 'orig' ? srcName(S.settings.srcLang) : tgtName(l)} ${c}`).join(' · ');
  txt.innerHTML = `Code <b class="mono">${LIVE.code}</b>${n ? ` · ${esc(langs)}` : ' · waiting for students to join'}`;
  btn.innerHTML = `${icon('qr')}Show join code`; qb.hidden = false; qb.textContent = LIVE.showQR ? 'Hide code on screen' : 'Show code on screen';
  renderStageQR();
}
async function renderStageQR() {
  const box = $('#stage-qr'); if (!box) return;
  if (!LIVE.code || !LIVE.showQR) { box.hidden = true; return; }
  const url = joinUrl(LIVE.code);
  box.hidden = false;
  box.innerHTML = `<div class="qr-wrap">${await qrSvg(url)}</div><div><div class="qr-code mono">${LIVE.code}</div><div class="qr-url">${esc(shortUrl(url))}</div><div class="qr-hint">Scan for captions in your language</div></div>`;
}
async function openShareSheet() {
  if (!LIVE.code) { const ok = await startSharing(); if (!ok) return; }
  const url = joinUrl(LIVE.code);
  openSheet('Students join here', `
    <div class="share-hero"><div class="qr-wrap big">${await qrSvg(url)}</div>
      <div class="share-info"><span class="eyebrow">Join code</span><div class="qr-code mono">${LIVE.code}</div>
      <span class="eyebrow">Or open</span><div class="share-url mono" id="share-url">${esc(url)}</div>
      <div class="row"><button class="btn sm" id="share-copy">${icon('copy')}Copy link</button></div></div></div>
    <p class="small muted" style="margin:0">Students scan the code, choose a language, and see your captions live. No account or app install needed. Translations use this device’s AI model, so each extra language adds a little usage.</p>
    <div class="row"><button class="btn primary" id="share-show">${LIVE.showQR ? 'Hide' : 'Show'} code on the caption screen</button><button class="btn ghost danger" id="share-stop">Stop sharing</button></div>`,
    sh => {
      $('#share-copy', sh).onclick = () => copyText(url);
      $('#share-show', sh).onclick = () => { LIVE.showQR = !LIVE.showQR; renderShare(); closeSheet(); };
      $('#share-stop', sh).onclick = () => { closeSheet(); stopSharing(); };
    });
}

/* ================= Live quiz (presenter side) ================= */
const PALETTE = [['Red', '#e5484d'], ['Orange', '#f76b15'], ['Amber', '#e2a336'], ['Lime', '#7cb342'], ['Green', '#30a46c'], ['Teal', '#12a594'], ['Sky', '#0d9adb'], ['Blue', '#3e63dd'], ['Indigo', '#5b5bd6'], ['Violet', '#8e4ec6'], ['Pink', '#d6409f'], ['Coral', '#ec5e5e'], ['Gold', '#c29b0c'], ['Jade', '#29a383'], ['Plum', '#ab4aba'], ['Navy', '#2f4e9e']];
const ANIMALS = 'Otter Fox Heron Lynx Panda Koala Falcon Beaver Bison Owl Badger Dolphin Gecko Ibex Jaguar Kiwi Lemur Manatee Narwhal Ocelot Penguin Quokka Raven Seal Tapir Walrus Yak Zebra Moose Puffin Sloth Turtle Wombat Hedgehog Crane Marmot Orca Llama Hare Toucan Axolotl Bobcat Capybara Dingo Egret Ferret Gazelle Hippo Iguana Jackal Kestrel Lobster Meerkat Newt Okapi Pelican Robin Salmon Tiger Viper Wolf'.split(' ');
const OPT_COLORS = ['#e5484d', '#3e63dd', '#e2a336', '#30a46c'];
const displayName = (p, mode) => (mode === 'ask' && p?.name) ? p.name : (p ? `${p.color} ${p.animal}` : 'Someone');
const colorHex = c => (PALETTE.find(p => p[0] === c) || [0, '#888'])[1];
function liveQuizSettings() { return { duration: +$('#quiz-timer').value, nameMode: $('#quiz-names').value, showBoard: $('#quiz-board').checked }; }
async function openLiveQuiz() {
  const qs = S.lecture.quiz?.questions || [];
  if (!qs.length) { toast('Generate a quiz first.'); return; }
  if (!LIVE.code && !(await startSharing())) return;
  const set = liveQuizSettings();
  LIVE.q = { ...set, i: -1, state: 'lobby', qs, results: {}, scores: {}, responses: {}, startedAt: 0, off: null, timer: null };
  await LIVE.ref.update({ quiz: { state: 'lobby', total: qs.length, nameMode: set.nameMode, duration: set.duration, showBoard: set.showBoard }, reveal: null, responses: null, scores: null });
  let ov = $('#liveq');
  if (!ov) { ov = document.createElement('div'); ov.id = 'liveq'; ov.className = 'present liveq'; ov.setAttribute('role', 'dialog'); ov.setAttribute('aria-label', 'Live quiz'); document.body.appendChild(ov); }
  ov.hidden = false; document.body.style.overflow = 'hidden';
  try { ov.requestFullscreen?.().catch(() => {}); } catch { /* optional */ }
  renderLiveQuiz();
}
function closeLiveQuiz(silent) {
  const q = LIVE.q; if (!q) return;
  clearInterval(q.timer); q.off && q.off();
  if (LIVE.ref && !silent) LIVE.ref.update({ quiz: { state: 'closed' } }).catch(() => {});
  if (!q.saved && Object.keys(q.results).length) saveQuizRun(q);
  LIVE.q = null;
  const ov = $('#liveq'); if (ov) ov.hidden = true;
  document.body.style.overflow = ''; if (document.fullscreenElement) document.exitFullscreen?.();
}
function saveQuizRun(q) {
  const L = S.lecture; L.quiz.runs = L.quiz.runs || [];
  L.quiz.runs.push({ at: Date.now(), nameMode: q.nameMode, people: Object.fromEntries(Object.entries(LIVE.people).map(([k, p]) => [k, displayName(p, q.nameMode)])), results: q.results, scores: q.scores });
  saveSoon();
}
async function askQuestion(i) {
  const q = LIVE.q; q.i = i; q.state = 'question';
  const item = q.qs[i];
  clearInterval(q.timer); q.off && q.off(); q.responses = {};
  await LIVE.ref.child('quiz').update({ state: 'question', index: i, startedAt: TS(), q: { stem: item.stem, options: item.options, type: item.type || 'mc' } });
  q.startedAt = (await LIVE.ref.child('quiz/startedAt').once('value')).val() || serverNow();
  const rref = LIVE.ref.child('responses/' + i);
  const cb = rref.on('value', s => { q.responses = s.val() || {}; renderLiveQuiz(); maybeAutoReveal(); });
  q.off = () => rref.off('value', cb);
  q.timer = setInterval(() => { updateCountdown(); maybeAutoReveal(); }, 200);
  renderLiveQuiz();
}
function onlineCount() { return Object.values(LIVE.people).filter(p => p.online !== false).length; }
function maybeAutoReveal() {
  const q = LIVE.q; if (!q || q.state !== 'question') return;
  const answered = Object.keys(q.responses).length, n = onlineCount();
  const timeUp = q.duration && serverNow() >= q.startedAt + q.duration * 1000;
  if (timeUp || (n > 0 && answered >= n)) reveal();
}
function updateCountdown() {
  const q = LIVE.q; const el = $('#lq-time'); if (!q || !el || !q.duration) return;
  const rem = Math.max(0, q.startedAt + q.duration * 1000 - serverNow());
  el.textContent = Math.ceil(rem / 1000); $('#lq-bar').style.transform = `scaleX(${rem / (q.duration * 1000)})`;
}
async function reveal() {
  const q = LIVE.q; if (!q || q.state !== 'question') return;
  q.state = 'reveal'; clearInterval(q.timer); q.off && q.off();
  const item = q.qs[q.i], counts = item.options.map(() => 0), win = (q.duration || 30) * 1000;
  for (const [pid, r] of Object.entries(q.responses)) {
    if (r.c >= 0 && r.c < counts.length) counts[r.c]++;
    const pts = r.c === item.answer ? Math.round(500 + 500 * Math.max(0, 1 - (r.ms || win) / win)) : 0;
    q.scores[pid] = (q.scores[pid] || 0) + pts;
  }
  q.results[q.i] = q.responses;
  await LIVE.ref.update({ [`reveal/${q.i}`]: { answer: item.answer, explanation: item.explanation || '', counts }, scores: q.scores, 'quiz/state': 'reveal' });
  renderLiveQuiz();
}
async function endQuiz() {
  const q = LIVE.q; q.state = 'ended'; clearInterval(q.timer); q.off && q.off();
  await LIVE.ref.child('quiz/state').set('ended');
  saveQuizRun(q); q.saved = true;
  renderLiveQuiz();
}
function boardRows(q, limit) {
  return Object.entries(q.scores).sort((a, b) => b[1] - a[1]).slice(0, limit).map(([pid, sc], k) => {
    const p = LIVE.people[pid];
    return `<li><span class="rank">${k + 1}</span><span class="dot" style="background:${colorHex(p?.color)}"></span><span class="grow">${esc(displayName(p, q.nameMode))}</span><b class="mono">${sc}</b></li>`;
  }).join('');
}
async function renderLiveQuiz() {
  const q = LIVE.q, ov = $('#liveq'); if (!q || !ov) return;
  const n = onlineCount(), url = joinUrl(LIVE.code, true);
  const people = Object.entries(LIVE.people).filter(([, p]) => p.online !== false);
  const top = `<div class="present-top"><span class="count">${q.state === 'lobby' ? 'Live quiz · lobby' : q.state === 'ended' ? 'Results' : `Question ${q.i + 1} of ${q.qs.length}`} · ${n} connected</span><button class="btn sm" id="lq-close">${icon('close')}Close</button></div>`;
  let body = '', nav = '';
  if (q.state === 'lobby') {
    body = `<div class="lobby"><div class="qr-wrap big">${await qrSvg(url)}</div>
      <div class="lobby-info"><span class="eyebrow">Join at</span><div class="share-url mono">${esc(shortUrl(url))}</div><span class="eyebrow">Code</span><div class="qr-code mono">${LIVE.code}</div>
      <p class="present-explain">${q.nameMode === 'ask' ? 'Students type their name when they join.' : 'Each student is given a color-and-animal name.'} ${q.duration ? `${q.duration} seconds per question.` : 'No time limit.'} ${q.qs.length} questions.</p></div></div>
      <ul class="names">${people.map(([, p]) => `<li style="--c:${colorHex(p.color)}">${esc(displayName(p, q.nameMode))}</li>`).join('') || '<li class="muted-li">Waiting for students…</li>'}</ul>`;
    nav = `<button class="btn primary" id="lq-start" ${n ? '' : 'disabled'}>Start quiz</button>`;
  } else if (q.state === 'question' || q.state === 'reveal') {
    const item = q.qs[q.i], resp = Object.values(q.responses), total = Math.max(1, resp.length);
    const counts = item.options.map((_, k) => resp.filter(r => r.c === k).length);
    const rv = q.state === 'reveal';
    body = `${q.duration && !rv ? `<div class="lq-timer"><span id="lq-time" class="mono">${q.duration}</span><div class="lq-track"><div id="lq-bar"></div></div></div>` : ''}
      <h2 class="present-stem">${esc(item.stem)}</h2>
      <div class="present-opts ${item.type === 'tf' ? 'tf' : ''}">${item.options.map((o, k) => `<div class="p-opt ${rv ? (k === item.answer ? 'correct' : 'dim') : ''}" style="--oc:${OPT_COLORS[k]}"><span class="L">${optLetter(item, k)}</span><span class="grow">${esc(o)}</span>${rv ? `<span class="bar-count mono">${counts[k]}</span><span class="bar" style="width:${Math.round(counts[k] / total * 100)}%"></span>` : ''}</div>`).join('')}</div>
      ${rv ? `${item.explanation ? `<p class="present-explain">${esc(item.explanation)}</p>` : ''}<p class="present-explain"><b>${resp.length ? Math.round(counts[item.answer] / resp.length * 100) : 0}% correct</b> · ${resp.length} answered</p>${q.showBoard && Object.keys(q.scores).length ? `<ol class="board">${boardRows(q, 5)}</ol>` : ''}`
        : `<p class="present-explain"><b>${resp.length}</b> of ${n} answered</p>`}`;
    nav = rv ? (q.i < q.qs.length - 1 ? `<button class="btn primary" id="lq-next">Next question</button>` : `<button class="btn primary" id="lq-end">See results</button>`) : `<button class="btn" id="lq-reveal">Reveal answer now</button>`;
  } else if (q.state === 'ended') {
    const rows = q.qs.map((item, i) => { const r = Object.values(q.results[i] || {}); const pct = r.length ? Math.round(r.filter(x => x.c === item.answer).length / r.length * 100) : 0; return `<li><span class="mono">${pad(i + 1)}</span><span class="grow">${esc(item.stem.slice(0, 90))}${item.stem.length > 90 ? '…' : ''}</span><span class="pct-track"><span style="width:${pct}%"></span></span><b class="mono">${pct}%</b></li>`; }).join('');
    const all = Object.values(q.results).flatMap((res, i) => Object.values(res).map(r => r.c === q.qs[+Object.keys(q.results)[i]]?.answer));
    const avg = all.length ? Math.round(all.filter(Boolean).length / all.length * 100) : 0;
    body = `<h2 class="present-stem">Class average: ${avg}% correct</h2><ul class="qstats">${rows}</ul>${q.showBoard ? `<ol class="board">${boardRows(q, 10)}</ol>` : ''}<p class="present-explain">Results are saved with this lecture. Download them for your gradebook or to plan reteaching.</p>`;
    nav = `<button class="btn primary" id="lq-csv">${icon('down')}Download results (.csv)</button><button class="btn" id="lq-again">Run again</button>`;
  }
  ov.innerHTML = `${top}<div class="present-body">${body}</div><div class="present-nav">${nav}</div>`;
  $('#lq-close', ov).onclick = () => closeLiveQuiz();
  const b = id => $(id, ov);
  if (b('#lq-start')) b('#lq-start').onclick = () => askQuestion(0);
  if (b('#lq-reveal')) b('#lq-reveal').onclick = reveal;
  if (b('#lq-next')) b('#lq-next').onclick = () => askQuestion(q.i + 1);
  if (b('#lq-end')) b('#lq-end').onclick = endQuiz;
  if (b('#lq-csv')) b('#lq-csv').onclick = () => saveFile(slug(S.lecture.title) + '-quiz-results.csv', quizResultsCsv(q), 'text/csv');
  if (b('#lq-again')) b('#lq-again').onclick = () => { closeLiveQuiz(true); openLiveQuiz(); };
  updateCountdown();
}
function quizResultsCsv(q) {
  const head = ['Participant', 'Score', 'Correct', ...q.qs.map((_, i) => `Q${i + 1}`)];
  const ids = new Set(Object.values(q.results).flatMap(r => Object.keys(r)));
  const rows = [...ids].map(pid => {
    const p = LIVE.people[pid]; let correct = 0;
    const cells = q.qs.map((item, i) => { const r = q.results[i]?.[pid]; if (!r) return ''; if (r.c === item.answer) correct++; return `${optLetter(item, r.c)}${r.c === item.answer ? ' ✓' : ''}`; });
    return [displayName(p, q.nameMode), q.scores[pid] || 0, `${correct}/${q.qs.length}`, ...cells];
  }).sort((a, b) => b[1] - a[1]);
  const key = ['Answer key', '', '', ...q.qs.map(item => optLetter(item, item.answer))];
  return '﻿' + [head, key, ...rows].map(r => r.map(csvCell).join(',')).join('\r\n');
}
